const auth = require('./auth')
const biodata = require('./biodata')
const history = require('./history')

module.exports = {auth, biodata, history}